#/bin/sh
while true; do
    read -p "     Do you wish to run a test example? [y/n]   " yn
    case $yn in
        [Yy]* )
	    echo  '     Running test for pregenerated test_derllyan.lhe file'
	    sed -i -e "s/from user_input import/from test_input import/g" link_source.py
	    git clone https://github.com/AhmedHammad1/test2.git
	    cp -rf test2/* .
	    sudo python link_source.py
            rm -rf test_input.py
            rm -rf test2/
	    exit;;
        [Nn]* )
	    sed -i -e "s/from test_input import/from user_input import/g" link_source.py
	    sudo python link_source.py
	    exit;;

	
        * ) echo "     Please answer y or n.";;
    esac
done

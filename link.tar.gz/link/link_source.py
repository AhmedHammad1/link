#!/usr/bin/python
print ''' ***********************************************
 *  Script to Link LesHouches events at parton *
 *  level to Pythia8 including jet merging     *
 *  (MLM/CKKW) + Delphes + MadAnalysis         *
 *********************************************** '''

import fileinput
import os
import random
import re
import sys
import shutil
#import cmath 
#import numpy as np
import array
import time
from test_input import * 
from os import remove
from shutil import move
import tarfile
import glob
path = os.getcwd()

##############################################
name = lhe.rsplit(".")
##############################################
########### preparing LesHouches file ########
root=open (lhe)
f = open ('fout','w+')
for y in root:
    if '<LesHouchesEvents version="2.0">' in y:
        y =y.replace('<LesHouchesEvents version="2.0">','<LesHouchesEvents version="1.0">')
    if '<LesHouchesEvents version="3.0">' in y:
        y =y.replace('<LesHouchesEvents version="3.0">','<LesHouchesEvents version="1.0">')
    f.write(y)
os.rename('fout',lhe)
f.close()
######################################
if not os.path.exists(str(path)+str('/Pythia.822/pythia/hepmc/lib')):
    print '---> pythia8 not installed in %s, '%str(path)
    if os.path.exists(str(path)+str('/Pythia.822/')):
        shutil.rmtree(str(path)+str('/Pythia.822/'))
    print '---> Downloading Pythia8'    
    os.system('git clone https://github.com/AhmedHammad1/Pythia.822.git')
    os.chdir(str(path)+str('/Pythia.822'))
    print '---> Install Pythia8'
    os.system('tar zxvf pythia.tar.gz')
    os.remove(str(path)+str('/Pythia.822/pythia.tar.gz'))
    os.remove(str(path)+str('/Pythia.822/README.md'))
    os.chdir(str(path)+str('/Pythia.822/pythia/hepmc'))
    print'---> hepmc will confugured with units GEV and CM'
    time.sleep(5)
    os.system('./configure --prefix=%s/Pythia.822/pythia/hepmc/ --with-momentum=GEV --with-length=CM'%str(path))
    os.system('make')
    os.system('make install')
    os.chdir(str(path)+str('/Pythia.822/pythia/'))
    os.system('./configure --with-hepmc2=%s/Pythia.822/pythia/hepmc/  --with-hepmc2-include=%s/Pythia.822/pythia/hepmc/include --cxx-common=\'-ldl -fPIC -lstdc++\''%(str(path),str(path)))
    time.sleep(5)
    os.system('make')
    os.system('make install')
    os.chdir(str(path)+str('/Pythia.822/pythia/examples/'))
    print '---> Creating HepMC link'
    time.sleep(5)
    os.system('make main42')
    os.system('make main89')
 #   os.chdir(str(path)+str('/Pythia_82/pythia/rootexamples/'))
 #   print '---> Creating Pythia_ROOT link'
 #   os.system('make hist')
    print '---> pythia8 installed in %s'%str(path)
    time.sleep(5)
    os.chdir(str(path))
else:
    print '---> pythia8 installed'
if  not os.path.exists(str(path)+str('/delphes/delphes/DelphesHepMC')):
    print '---> delphes not installed in %s,'%str(path)
    print ''' ************************************************
 *  Please be sure that root-config is activated *
 ************************************************ '''
    if os.path.exists(str(path)+str('/delphes/')):
        shutil.rmtree(str(path)+str('/delphes/'))
    print 'Downloading delphes'    
    os.system('git clone https://github.com/AhmedHammad1/delphes.git')
    print '---> Installing delphes'
    os.chdir((str(path)+str('/delphes/')))
    os.system('tar zxvf delphes.tar.gz')
    os.remove('delphes.tar.gz')
    os.remove('README.md')
    os.chdir((str(path)+str('/delphes/delphes')))
    os.system('make')
    time.sleep(4)
    if not os.path.exists(str(path)+str('/delphes/delphes/DelphesHepMC')):
        print ''' ********************************
    *       Delphes not installed 
    *          EXIT !!!!!!!!!!!                                          
    *********************************************** '''%str(path)
        exit()   
    os.chdir(str(path))
    print '---> delphes installed in %s'%str(path)
    time.sleep(5)
else:
    print '---> delphes installed'
if not os.path.exists(str(path)+str('/madanalysis5/')):
    print '---> madanalysis5 not installed in %s,'%str(path)
    print '---> Downloading MadAnalysis'
    os.system('wget \'https://launchpad.net/madanalysis5/trunk/v1.4/+download/MadAnalysis5_v1.4.tar.gz\'')
    os.system('tar zxvf MadAnalysis5_v1.4.tar.gz')
    print '---> MadAnalaysis installed in %s'%str(path)
    time.sleep(5)
else:    
    print '---> MadAnalysis5 installed'
###########################################
if (merging == '0'):
    os.chdir(str(path)+str('/Pythia.822/pythia/examples/'))
    root=open ('main42.cmnd')
    f = open ('fout','w+')
    for y in root:
        if str ('Beams:LHEF') in y:
            x = y.rsplit()
            y = y.replace(str(x[2]),str(path)+'/'+str(lhe))
        if str ('PartonLevel:MPI') in y:
            x = y.rsplit()
            y = y.replace(str(x[2]),str(Multiple_interaction))
        if str ('PartonLevel:ISR') in y:
            x = y.rsplit()
            y = y.replace(str(x[2]),str(Initial_state_radiation))
        if str ('PartonLevel:FSR') in y:
            x = y.rsplit()
            y = y.replace(str(x[2]),str(Final_state_radiation))
        if str ('HadronLevel:Hadronize') in y:
            x = y.rsplit()
            y = y.replace(str(x[2]),str(Hadronizatoin))
        if str ('HadronLevel:Decay') in y:
            x = y.rsplit()
            y = y.replace(str(x[2]),str(Decay_of_heavy_hadrons))
        if str ('PartonLevel:Remnants') in y:
            x = y.rsplit()
            y = y.replace(str(x[2]),str(Beam_remnants))
        f.write(y)
    os.rename('fout','main42.cmnd')
    f.close()
    print '---> Creating hepMC file, please  be patient it takes awhile'
    print '---> please take a look at %s/pythia.log to catch the modified cross section'%str(path)
    os.system('./main42 main42.cmnd H.hep > pythia.log')
    if os.path.exists(str(path)+'/pythia.log'):
        os.remove(str(path)+'/pythia.log')
    shutil.move(str(path)+str('/Pythia.822/pythia/examples/pythia.log'),path)
    if not os.path.exists(str(path)+str('/Pythia.822/pythia/examples/H.hep')):
        print ''' ******************************************************************
    * Pythia couldnt produce hepmc file please take a look at %s/pythia.log 
    *          EXIT !!!!!!!!!!!                                          
    ****************************************************************** '''%str(path)
        exit()            
    if os.path.exists(str(path)+str('/Pythia.822/pythia/examples/H.hep')):    
        os.rename('H.hep',str(name[0])+'_pythia.hep')
        os.chdir(str(path))
        if os.path.exists(str(path)+'/'+str(name[0])+'_pythia.hep'):
            os.remove(str(path)+'/'+str(name[0])+'_pythia.hep')
        shutil.move(str(path)+str('/Pythia.822/pythia/examples/')+str(name[0])+'_pythia.hep',path)
##############################################
if (merging == '1'):
    os.chdir(str(path)+str('/Pythia.822/pythia/examples/'))
    root=open ('main89ckkwl.cmnd')
    f = open ('fout','w+')
    for y in root:
        if str ('Beams:LHEF') in y:
            x = y.rsplit()
            y = y.replace(str(x[2]),str(path)+'/'+str(lhe))
        f.write(y)
    os.rename('fout','main89ckkwl.cmnd')
    f.close()
    print '---> Creating hepMC file, please be patient it takes awhile'
    
    print '---> please take a look at %s/pythia.log to catch the modified cross section'%str(path)
    os.system('./main89 main89ckkwl.cmnd H.hep > pythia.log')
    if os.path.exists(str(path)+'/pythia.log'):
        os.remove(str(path)+'/pythia.log')
    shutil.move(str(path)+str('/Pythia.822/pythia/examples/pythia.log '),path)
    if not os.path.exists(str(path)+str('/Pythia.822/pythia/examples/H.hep')):
        print ''' ******************************************************************
    * Pythia couldnt produce hepmc file please take a look at pythia.log 
    *          EXIT !!!!!!!!!!!                                          
    ****************************************************************** '''
        exit()            
    if os.path.exists(str(path)+str('/Pythia.822/pythia/examples/H.hep')):    
        os.rename('H.hep',str(name[0])+'_pythia.hep')
        os.chdir(str(path))
        if os.path.exists(str(path)+'/'+str(name[0])+'_pythia.hep'):
            os.remove(str(path)+'/'+str(name[0])+'_pythia.hep')
        shutil.move(str(path)+str('/Pythia.822/pythia/examples/')+str(name[0])+'_pythia.hep',path)
##############################################
if (merging == '2'):
    os.chdir(str(path)+str('/Pythia.822/pythia/examples/'))
    root=open ('main89mlm.cmnd')
    f = open ('fout','w+')
    for y in root:
        if str ('Beams:LHEF') in y:
            x = y.rsplit()
            y = y.replace(str(x[2]),str(path)+'/'+str(lhe))
        f.write(y)
    os.rename('fout','main89mlm.cmnd')
    f.close()
    print '---> Creating hepMC file, please be patient it takes awhile'
    
    print '---> please take a look at %s/pythia.log to catch the modified cross section'%str(path)
    os.system('./main89 main89mlm.cmnd H.hep > pythia.log')
    if os.path.exists(str(path)+'/pythia.log'):
        os.remove(str(path)+'/pythia.log')
    shutil.move(str(path)+str('/Pythia.822/pythia/examples/pythia.log'),path)
    if not os.path.exists(str(path)+str('/Pythia.822/pythia/examples/H.hep')):
        print ''' ******************************************************************
    * Pythia couldnt produce hepmc file please take a look at pythia.log 
    *          EXIT !!!!!!!!!!!                                          
    ****************************************************************** '''
        exit()            
    if os.path.exists(str(path)+str('/Pythia.822/pythia/examples/H.hep')):    
        os.rename('H.hep',str(name[0])+'_pythia.hep')
        os.chdir(str(path))
        if os.path.exists(str(path)+'/'+str(name[0])+'_pythia.hep'):
            os.remove(str(path)+'/'+str(name[0])+'_pythia.hep')
        shutil.move(str(path)+str('/Pythia.822/pythia/examples/')+str(name[0])+'_pythia.hep',path)
##############################################
if (Delphes == 'on'):
    os.chdir(str(path)+'/delphes/delphes')
    print '---> Runing delphes'
    if os.path.exists(str(path)+str('/delphes/delphes/delphes.root')):    
            os.remove(str(path)+str('/delphes/delphes/delphes.root'))
    os.system('./DelphesHepMC cards/delphes_card_CMS.tcl  delphes.root %s >/dev/null'%(str(path)+'/'+str(name[0])+'_pythia.hep'))
    #print (str(path)+'/'+str(name[0])+'.hep')
    if os.path.exists(str(path)+str('/delphes/delphes/delphes.root')):    
        os.rename('delphes.root',str(name[0])+'_delphes.root')
        os.system(' ./root2lhco %s  e.lhco'%(str(name[0])+'_delphes.root'))
        if os.path.exists(str(path)+str('/delphes/delphes/e.lhco')):    
            os.rename('e.lhco',str(name[0])+'_delphes.lhco')
        os.chdir(str(path))
        if os.path.exists(str(path)+'/'+str(name[0])+'_delphes.root'):
            os.remove(str(path)+'/'+str(name[0])+'_delphes.root')
        shutil.move(str(path)+str('/delphes/delphes/')+str(name[0])+'_delphes.root',path)
    if os.path.exists(str(path)+'/'+str(name[0])+'_delphes.lhco'):
            os.remove(str(path)+'/'+str(name[0])+'_delphes.lhco')
    shutil.move(str(path)+str('/delphes/delphes/')+str(name[0])+'_delphes.lhco',path)
##########################################################################################
if (madanalysis == 'on'):
    os.chdir(str(path)+'/madanalysis5')
    root=open (str(path)+'/madanalysis5/madanalysis/input/installation_options.dat')
    f = open ('fout','w+')
    for y in root:
        if str ('# fastjet_veto     = 0') in y:
            y = y.replace('# fastjet_veto     = 0',' fastjet_veto     = 1')
        f.write(y)
    os.rename('fout',str(path)+'/madanalysis5/madanalysis/input/installation_options.dat')
    f.close()    
    print '---> Runing madanalysis5'
    mad = open ('setup.sh','w+')
    mad.write('''#!/bin/bash
./bin/ma5 -s gen.txt''')
    os.system('chmod 777 setup.sh')
    gen = open ('gen.txt','w+')
    gen.write('''define l = l+ l-
define j = u u~ d d~ c c~ s s~ g
define mu = mu+ mu-
define ta = ta+ ta-
import %s as sig \n'''%(str(path)+'/'+(str(lhe))))
    gen.write('set sig.xsection = %s \n'%(str(cross_section)))
    gen.write('set main.lumi = %s \n'%(str(Lumi)))
    gen.write('set main.normalize = lumi_weight \n')
    gen.write('plot  %s \n'%(str(plot)))
    gen.write('submit gen')
    mad.close()
    gen.close()
    print'---> Running MadAnalysis for Gen level'
    os.system('./setup.sh ')
    if os.path.exists(str(path)+'/madanalysis_gen.log'):
        os.remove(str(path)+'/madanalysis_gen.log')
    #shutil.move(str(path)+'/madanalysis5/madanalysis_gen.log',path)
    os.remove('setup.sh')
    os.remove('gen.txt')
    os.rename(str(path)+'/madanalysis5/gen/PDF/selection_0.png',str(path)+'/madanalysis5/gen/PDF/'+str(name[0])+'_gen.png')
    if os.path.exists(str(path)+'/'+str(name[0])+'_gen.png'):
        os.remove(str(path)+'/'+str(name[0])+'_gen.png')
    shutil.move(str(path)+'/madanalysis5/gen/PDF/'+str(name[0])+'_gen.png',path)
    shutil.rmtree(str(path)+'/madanalysis5/gen/')
    #################################################################
    mad = open ('setup.sh','w+')
    mad.write('''#!/bin/bash
./bin/ma5 -s -R gen.txt''')
    os.system('chmod 777 setup.sh')
    gen = open ('gen.txt','w+')
    gen.write('''define l = l+ l-
define mu = mu+ mu-
define ta = ta+ ta-
import %s as sig \n'''%(str(path)+'/'+str(name[0])+'_delphes.lhco'))
    gen.write('set sig.xsection = %s \n'%(str(cross_section)))
    gen.write('set main.lumi = %s \n'%(str(Lumi)))
    gen.write('set main.normalize = lumi_weight \n')
    gen.write('plot  %s \n'%(str(plot)))
    gen.write('submit gen')
    mad.close()
    gen.close()
    print'---> Running MadAnalysis for Reco level'
    os.system('./setup.sh >> madanalysis_gen.log')
    if os.path.exists(str(path)+'/madanalysis_gen.log'):
        os.remove(str(path)+'/madanalysis_gen.log')
    shutil.move(str(path)+'/madanalysis5/madanalysis_gen.log',path)
    os.remove('setup.sh')
    os.remove('gen.txt')
    os.rename(str(path)+'/madanalysis5/gen/PDF/selection_0.png',str(path)+'/madanalysis5/gen/PDF/'+str(name[0])+'_reco.png')
    if os.path.exists(str(path)+'/'+str(name[0])+'_reco.png'):
        os.remove(str(path)+'/'+str(name[0])+'_reco.png')
    shutil.move(str(path)+'/madanalysis5/gen/PDF/'+str(name[0])+'_reco.png',path)
    shutil.rmtree(str(path)+'/madanalysis5/gen/')
os.chdir(str(path))

